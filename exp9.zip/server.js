// Import core modules
const http = require('http');
const os = require('os');
const path = require('path');
const events = require('events');

// Create an event emitter
const eventEmitter = new events.EventEmitter();

// Event handler for custom event
eventEmitter.on('userVisited', (url) => {
    console.log(`User visited: ${url}`);
});

// Create HTTP server
const server = http.createServer((req, res) => {
    // Emit custom event
    eventEmitter.emit('userVisited', req.url);

    // Routing
    if (req.url === '/') {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end('<h1>Welcome to Custom Node Server</h1>');
    } else if (req.url === '/system') {
        // Use OS module
        const systemInfo = {
            hostname: os.hostname(),
            platform: os.platform(),
            architecture: os.arch(),
            cpus: os.cpus().length,
            memory: `${(os.totalmem() / (1024 * 1024 * 1024)).toFixed(2)} GB`,
            uptime: `${(os.uptime() / 60).toFixed(2)} minutes`
        };

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(systemInfo));
    } else if (req.url === '/path') {
        // Use path module
        const filePath = path.join(__dirname, 'public', 'index.html');
        const pathInfo = {
            base: path.basename(filePath),
            dir: path.dirname(filePath),
            ext: path.extname(filePath),
            resolved: path.resolve(filePath)
        };

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(pathInfo));
    } else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('404 Not Found');
    }
});

// Start server
const PORT = 3000;
server.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}/`);
});
