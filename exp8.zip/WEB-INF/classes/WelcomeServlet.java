import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class WelcomeServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();

        // Check for reset action
        String reset = request.getParameter("reset");
        if ("true".equals(reset)) {
            // Invalidate cookie
            Cookie cookie = new Cookie("username", "");
            cookie.setMaxAge(0); // Delete cookie
            response.addCookie(cookie);

            // Invalidate session data
            session.invalidate();

            out.println("<h2>Cookie and session have been reset.</h2>");
            out.println("<p><a href='index.html'>Go Back</a></p>");
            return;
        }

        // Get username from request or session
        String username = request.getParameter("username");
        if (username == null) {
            username = (String) session.getAttribute("username");
        } else {
            session.setAttribute("username", username);

            // Set cookie
            Cookie nameCookie = new Cookie("username", username);
            nameCookie.setMaxAge(60 * 60); // 1 hour
            response.addCookie(nameCookie);
        }

        // Visit count
        Integer visitCount = (Integer) session.getAttribute("visitCount");
        visitCount = (visitCount == null) ? 1 : visitCount + 1;
        session.setAttribute("visitCount", visitCount);

        if (username != null) {
            out.println("<h2>Hello, " + username + "!</h2>");
            out.println("<p>This is your visit number: " + visitCount + "</p>");
        } else {
            out.println("<p>No username found. Please <a href='index.html'>go back</a> and enter your name.</p>");
        }

        out.println("<p><a href='index.html'>Go Back</a></p>");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }
}










