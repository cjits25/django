<?php
session_start();

if($_SESSION['role']!="admin"){
header("Location: login.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
<div class="container">

<a class="navbar-brand fw-bold" href="index.php">
Student Management System
</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="navbarNav">

<ul class="navbar-nav ms-auto">

<li class="nav-item">
<a href="logout.php" class="btn btn-danger">Logout</a>
</li>

</ul>

</div>
</div>
</nav>
<div class="container mt-5 text-center">

<h2>Admin Dashboard</h2>
<h4>Welcome <?php echo $_SESSION['username']; ?></h4>

</div>

</body>
</html>