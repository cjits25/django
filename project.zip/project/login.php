<?php
session_start();
include "db.php";

if(isset($_POST['login'])){

$username=$_POST['username'];
$password=$_POST['password'];

$sql="SELECT * FROM users WHERE username='$username' AND password='$password'";
$result=$conn->query($sql);

if($result->num_rows>0){

$row=$result->fetch_assoc();

$_SESSION['username']=$row['username'];
$_SESSION['role']=$row['role'];

if($row['role']=="admin"){
header("Location: admin_dashboard.php");
}else{
header("Location: user_dashboard.php");
}

}else{
echo "Invalid Username or Password";
}

}
?>

<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>

<body class="bg-light">
<?php include('menu.php'); ?>
<div class="container mt-5">
<div class="row justify-content-center">
<div class="col-md-4">

<div class="card">
<div class="card-header text-center">Login</div>

<div class="card-body">

<form method="POST">

<input type="text" name="username" class="form-control mb-3" placeholder="Username" required>

<input type="password" name="password" class="form-control mb-3" placeholder="Password" required>

<button name="login" class="btn btn-primary w-100">Login</button>

</form>
New User : <a href ="register.php">Registration</a>
</div>
</div>

</div>
</div>
</div>

</body>
</html>