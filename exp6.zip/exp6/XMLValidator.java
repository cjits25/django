import java.io.File;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import org.w3c.dom.Document;
public class XMLValidator {
 public static void main(String[] args) {
 String xmlFile = "bookstore.xml";
 String dtdFile = "bookstore.dtd";
 String xsdFile = "bookstore.xsd";
 // Validate XML with DTD
 if (validateWithDTD(xmlFile, dtdFile)) {
 System.out.println("XML is valid against DTD.");
 } else {
 System.out.println("XML is NOT valid against DTD.");
 }
 // Validate XML with XSD
 if (validateWithXSD(xmlFile, xsdFile)) {
 System.out.println("XML is valid against XSD.");
 } else {
 System.out.println("XML is NOT valid against XSD.");
 }
 }
 public static boolean validateWithDTD(String xmlFile, String dtdFile) {
 try {
 DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
 factory.setValidating(true);
 factory.setNamespaceAware(true);
 DocumentBuilder builder = factory.newDocumentBuilder();
 builder.setErrorHandler(null);
 Document document = builder.parse(new File(xmlFile));
 return true;
 } catch (Exception e) {
 System.err.println("DTD Validation Error: " + e.getMessage());
 return false;
 }
 }
 public static boolean validateWithXSD(String xmlFile, String xsdFile) {
 try {
 SchemaFactory factory = 
SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
 Schema schema = factory.newSchema(new File(xsdFile));
 Validator validator = schema.newValidator();
 Source source = new StreamSource(new File(xmlFile));
 validator.validate(source);
 return true;
 } catch (Exception e) {
 System.err.println("XSD Validation Error: " + e.getMessage());
 return false;
 }
 }
}