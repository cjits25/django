const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;
app.use(bodyParser.json());
const readData = () => {
const data = fs.readFileSync('students.json');
return JSON.parse(data);
};
const writeData = (data) => {
fs.writeFileSync('students.json', JSON.stringify(data, null, 2));
};
// Create Student (POST)
app.post('/students', (req, res) => {
const students = readData();
const newStudent = {
id: Date.now(),
name: req.body.name,
age: req.body.age,
course: req.body.course
};
students.push(newStudent);
writeData(students);
res.status(201).json(newStudent);
});
// Get All Students (GET)
app.get('/students', (req, res) => {
const students = readData();
res.json(students);
});
// Get Single Student (GET)
app.get('/students/:id', (req, res) => {
const students = readData();
const student = students.find(s => s.id === parseInt(req.params.id));
if (student) {
res.json(student);
} else {
res.status(404).json({ message: 'Student not found' });
}
});
// Update Student (PUT)
app.put('/students/:id', (req, res) => {
const students = readData();
const index = students.findIndex(s => s.id === parseInt(req.params.id));
if (index !== -1) {
students[index] = {
...students[index],
name: req.body.name || students[index].name,
age: req.body.age || students[index].age,
course: req.body.course || students[index].course
};
writeData(students);
res.json(students[index]);
} else {
res.status(404).json({ message: 'Student not found' });
}
});
// Delete Student (DELETE)
app.delete('/students/:id', (req, res) => {
let students = readData();
const newStudents = students.filter(s => s.id !== parseInt(req.params.id));
if (students.length === newStudents.length) {
return res.status(404).json({ message: 'Student not found' });
}
writeData(newStudents);
res.json({ message: 'Student deleted successfully' });
});
app.listen(PORT, () => {
console.log(`Server is running on http://localhost:${PORT}`);
});