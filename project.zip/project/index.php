<!DOCTYPE html>
<html>
<head>
<title>Home Page</title>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

</head>

<body class="bg-light">

<div class="container">

<div class="row justify-content-center align-items-center vh-100">

<div class="col-md-6 text-center">

<div class="card shadow">

<div class="card-header bg-primary text-white">
<h3>User Management System</h3>
</div>

<div class="card-body">

<p class="mb-4">Welcome to the Login System</p>

<a href="register.php" class="btn btn-success m-2">Register</a>

<a href="login.php" class="btn btn-primary m-2">Login</a>

</div>

</div>

</div>

</div>

</div>

</body>
</html>