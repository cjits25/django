<?php
include "db.php";

if(isset($_POST['register'])){

$username=$_POST['username'];
$password=$_POST['password'];
$role=$_POST['role'];

$sql="INSERT INTO users(username,password,role)
VALUES('$username','$password','$role')";

$conn->query($sql);

echo "User Registered Successfully";
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Register</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>

<body class="bg-light">
<?php include('menu.php'); ?>
<div class="container mt-5">
<div class="row justify-content-center">
<div class="col-md-4">

<div class="card">
<div class="card-header text-center">Register</div>

<div class="card-body">

<form method="POST">

<input type="text" name="username" class="form-control mb-3" placeholder="Username" required>

<input type="password" name="password" class="form-control mb-3" placeholder="Password" required>

<select name="role" class="form-control mb-3">
<option value="user">User</option>
<option value="admin">Admin</option>
</select>

<button name="register" class="btn btn-success w-100">Register</button>

</form>
Already Registered : <a href ="login.php">Login</a>
</div>
</div>

</div>
</div>
</div>

</body>
</html>